import numpy as np

class RPLSH:
    'Random Projection Locality Sensitive Hashing Class'

    def get_hash_code(self, x):
        hashcode = 0
        return hashcode

    def hash_dataset(self, dataset):
        pass

    def get_hash_entries(self, x):
        return[]

if __name__ == "__main__":
    pass